# Annotations Sample

![Plugin Demo](../_screenshots/annotations.gif)

This is a code sample that demonstrates how the Annotations API can be used to bulk create annotations on a specific type of node.

This code is distributed strictly for educational purposes. It's purely a starting point and you should modify it as needed for your specific purposes. As such, there are some known limitations.

## Known Limitations

This is a Dev Mode plugin that does not have a UI, it can be run via the Plugin tab in Dev Mode or via the Quick Actions Menu via the `CMD`+`/` (`CTRL`+`/` on Windows) keyboard shortcut
