# drag-and-drop-hosted

This sample plugin demonstrates drag-and-drop from a hosted plugin UI.

## Development

Serve up the `index.html` locally on port 4004, e.g.

```
python3 -m http.server 4004
```

Build the files:

```
tsc
```
